package com.onthemove.commons.utils;

public class Constants {

    public static final String IS_SIGN_UP ="IS_SIGN_UP";
    public static final String IS_LOGIN = "IS_LOGIN";
    public static final String USER_SESSION = "USER_SESSION";
    public static final String USER_TOKEN = "USER_TOKEN";
    public static final String USER_ID = "USER_ID";
    public static final String USER_NAME = "USER_NAME";

    public static final String MOBILE_NO = "MOBILE_NO";
    public static final String EMAIL = "EMAIL";
    public static final String ROLE = "ROLE";
    public static final String switchChecked = "switchChecked";




}
