package com.onthemove.interfaces;

import androidx.recyclerview.widget.RecyclerView;

public interface StartDragItemListner {
    void startDrag(RecyclerView.ViewHolder viewHolder);

}
