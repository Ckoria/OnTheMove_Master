package com.onthemove.interfaces;

public interface AdapterItemTouchListner {

    void itemMove(int oldPosition, int newPosition);
    void swipeItemDismiss(int position);
}
