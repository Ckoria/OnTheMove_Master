package com.onthemove.interfaces;


// This interface is used for viewHolder

public interface ViewHolderItemTouchListner {

    void itemSelected();
    void itemClear();
}
